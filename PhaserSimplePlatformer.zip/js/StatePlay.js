var statePlay = {

    create:                         function(){

        game.physics.arcade.gravity.y   = 1200;

        this.map                        = game.add.tilemap('Tilemap1');
        this.map.addTilesetImage        ('Tilemap1', 'ImageTilemap1');
        this.map.setCollisionByExclusion([0], true, 'LayerBlock');
        this.layerBackground            = this.map.createLayer('LayerBackground');
        this.layerBlock                 = this.map.createLayer('LayerBlock');
        this.keyboard                   = game.input.keyboard.createCursorKeys();

        this.seCoin                     = game.add.audio('SECoin');

        //A function to create coin object in the scene.
        this.ObjectCoinCreate();
        //A function to create player object in the scene.
        this.ObjectPlayerCreate();

    },

    update:                         function(){

        //A function to handle objects collision within the scene.
        this.CollisionObject();
        //A function to update player (movement, weapon range, etc).
        this.ObjectPlayerUpdate();
        //A function to handle objects overlap within the scene.
        this.OverlapObject();

    },

    CollisionObject:                function(){

        game.physics.arcade.collide(this.player,    this.layerBlock);
        game.physics.arcade.collide(this.coinGroup, this.layerBlock);

    },

    //A function to get reference from Tiled object layer from custom properties of 'type'.
    //This function is from http://www.gamedevacademy.org/html5-phaser-tutorial-top-down-games-with-tiled/
    FindGameObjectsByType:          function(_layer, _map, _type){

        var findObjects = new Array();
        _map.objects[_layer].forEach(

            function(_element){

                if(_element.properties.type == _type){

                    _element.y -= _map.tileHeight;
                    findObjects.push(_element);

                }

            }

        );
        return findObjects;

    },

    //A function for overlapping player object and coin object.
    PlayerCollectsCoin:             function(_player, _coin){

        //Codes to play sound.
        this.seCoin.play();
        //Codes to delete corresponding overlapping coin.
        _coin.destroy   (true);

    },

    ObjectCoinCreate:               function(){

        var findCoin                = this.FindGameObjectsByType('LayerObject', this.map, 'coin');
        this.coinGroup              = game.add.group();
        this.coinGroup.enableBody   = true;
        this.coinArray              = new Array(findCoin.length);

        for(var i = 0; i < findCoin.length; i ++){

            this.coinArray[i]                   = this.coinGroup.create(findCoin[i].x, findCoin[i].y, 'ImageCoin');
            game.physics.arcade.enable          (this.coinArray[i]);
            this.coinArray[i].body.immovable    = true;
            this.coinArray[i].body.moves        = false;

        }

    },

    ObjectPlayerCreate:             function(){

        var findPlayer                  = this.FindGameObjectsByType('LayerObject', this.map, 'playerPortal');
        this.player                     = game.add.sprite(findPlayer[0].x, findPlayer[0].y, 'ImagePlayer');
        this.player.enabledBody         = true;
        game.physics.arcade.enable      (this.player);

        //Codes to draw a line of player's weapon range.
        //this.rangeLength will be dependent to what weapon player equip.
        this.rangeLength                = 100;
        this.rangeLine                  = game.add.graphics(this.player.x, this.player.y);
        this.rangeLine.lineStyle        (1, 0xDF7126, 1);
        this.rangeLine.moveTo           (0, 0);
        this.rangeLine.lineTo           (this.rangeLength, 0);

    },

    ObjectPlayerUpdate:             function(){

        if      (game.input.keyboard.isDown(Phaser.Keyboard.A)) { this.player.body.velocity.x = -200; }
        else if (game.input.keyboard.isDown(Phaser.Keyboard.D)) { this.player.body.velocity.x = 200; }
        else                                    { this.player.body.velocity.x = 0; }

        if(

            game.input.keyboard.isDown(Phaser.Keyboard.W) &&
            this.player.body.onFloor()

        ){ this.player.body.velocity.y = -500; }

        //Codes to adjust this.rangeLine position according this.player position.
        //PROBLEM: this.rangeLine position is not always in sync (displaywise) with this.player position.
        this.rangeLine.x = this.player.x + (this.player.width/2);
        this.rangeLine.y = this.player.y + (this.player.height/2);
        this.rangeLine.rotation = Math.atan2((game.input.mousePointer.y - this.player.y), (game.input.mousePointer.x - this.player.x));
        this.rangeLine.width = this.rangeLength;

        console.log(
            'x: ' +
            (this.rangeLine.x - (this.player.width/2)) +
            ' ' +
            this.player.x +
            'y: ' +
            (this.rangeLine.y - (this.player.width/2)) +
            ' ' +
            this.player.y
        );

    },

    OverlapObject:                  function(){

        game.physics.arcade.overlap(this.player, this.coinGroup, this.PlayerCollectsCoin, null, this);

    }

};